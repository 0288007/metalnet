         *************************************************
         *  These fonts  are  FREEWARE for PERSONNAL USE *
         *************************************************

It is requested, however, that you neither modify them, nor change
their names.
You can distribute them to whomever you like, insofar as this file
"README.TXT " accompanies them.
To make these fonts, I used a software bought in the USA, and thus
I HAVE the LICENCE OF USE.
These fonts works perfectly well under WINDOWS 95,98,2000 and up
as well as on my own computer.
Anyway, I could not be held responsible for any possible problems
that could derive from their use.

To use these fonts under Windows (c), just place the xxxxx.ttf
files into your directory   c:/windows/fonts/

              That's all !...

Philippe BLONDEL

philing@hotmail.fr

http://philing.net 


                   Your Handwriting Font !...
            The Best Way to Humanize Your Computer !...


*****************************************************************