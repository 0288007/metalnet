======================================================================================================
                                                                                                       
   _|_|    _|      _|  _|_|_|_|    _|_|_|    _|_|    _|      _|  _|_|_|  _|        _|        _|_|_|_|  
 _|    _|  _|_|  _|_|  _|        _|        _|    _|  _|      _|    _|    _|        _|        _|        
 _|    _|  _|  _|  _|  _|_|_|    _|  _|_|  _|_|_|_|  _|      _|    _|    _|        _|        _|_|_|    
 _|    _|  _|      _|  _|        _|    _|  _|    _|    _|  _|      _|    _|        _|        _|        
   _|_|    _|      _|  _|_|_|_|    _|_|_|  _|    _|      _|      _|_|_|  _|_|_|_|  _|_|_|_|  _|_|_|_|  

 ____ ____ ____ ____ ____ ____ ____ ____ ____ _________ ____ ____ ____ ____ ____ 
||F |||o |||r |||g |||o |||t |||t |||e |||n |||       |||F |||o |||n |||t |||s ||
||__|||__|||__|||__|||__|||__|||__|||__|||__|||_______|||__|||__|||__|||__|||__||
|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/_______\|/__\|/__\|/__\|/__\|/__\|

======================================================================================================
                                                                                                       
Thank you for downloading one of my fonts!  This font is free to use.


Font Name:		Skate Rock

Original source:	Skate Rock

Original platform:	Commodore 64

Publisher:		Bubble Bus Software

Year:			1986


You can find some of my other work on Dafont or Fontstruct.  I'm also on Twitter @omegaville.

======================================================================================================

The font file in this archive was created using Fontstruct the free, online 
font-building tool.
This font was created by �Omegaville�.
This font has a homepage where this archive and other versions may be found:
https://fontstruct.com/fontstructions/show/1505246

Try Fontstruct at https://fontstruct.com
It�s easy and it�s fun.

Fontstruct is copyright �2018 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the file �license.txt� included with this archive.
If you redistribute the font file in this archive, it must be accompanied by all
 the other files from this archive, including this one.
