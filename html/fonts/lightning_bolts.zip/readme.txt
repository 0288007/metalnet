xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
x                                                                    x
x xxxxxxx xxxxxxx xxxxxxx xxxxxxx xx   xx    xxxxxxx xxxxxxx xx   xx x
x xx      xx   xx xx   xx xx   xx xx   xx    xx      xx   xx xxx xxx x
x xxxx    xx   xx xx   xx xxxxxxx xxxxxxx    xx      xx   xx xx x xx x
x xx      xx   xx xx   xx xx        xxx   xx xx      xx   xx xx   xx x
x xx      xxxxxxx xxxxxxx xx        xxx   xx xxxxxxx xxxxxxx xx   xx x
x                                                                    x
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Lightning Bolts - Freeware - Version 1.0

Freeware fonts are released as freeware for personal & commercial use
and for use by non profit organisations. You may use them on personal
or commercial sites; you may use them in printed material such as a
magazine or book, in electronic form such as embedded in a PDF or
MS Word document.

All fonts have been tested under Windows and in several applications
however all fonts are provided as is; FOOPY.COM accepts no liability
from their use including, but not limited to, loss of data or failure
of any application to recognize any font. Should you encounter
problems with any font please let us know:
http://www.foopy.com/contact.shtml

Conversions to Mac format are permissable according to the other
conditions set forth in this file.

FOOPY.COM retains copyright on all fonts released. Fonts may
not be reverse engineered without prior written permission. By
downloading and installing the fonts you agree to the terms and
conditions in this readme file.
                         
Distribution of Freeware fonts are permitted via the web
providing the readme.txt file (this file) is included in the
distribution. If you wish to include any Freeware
font on a CD ROM collection or bundled with any other software
you must contact FOOPY.COM for terms and conditions:
http://www.foopy.com/contact.shtml
                         
Distribution of derivative works such as tiles or desktop theme
sets from any Commercial Release, Sampler, Foopyware font and/or
Freeware font from commercial AND personal sites and use in/on any
other medium except traditional print and electronic form requires
a special license. Please contact FOOPY.COM for terms and conditions:
http://www.foopy.com/contact.shtml