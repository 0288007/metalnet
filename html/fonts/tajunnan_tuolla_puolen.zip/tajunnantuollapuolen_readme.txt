
This font was created by junkohanhero, (c) 2007. 
Free for non-profit and/or non-commercial usage.

Paying the commercial license fee gives you 
unlimited usage of thisfont for your t-shirts, 
advertisements, whatever you wish.
Ask more: junkohanhero@gmail.com 


dec2007
www.junkohanhero.com


