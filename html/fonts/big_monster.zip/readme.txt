This font "Big Monster" is created by Jack Oatley.
Co-member of Bitty/Brixdee on http://www.dafont.com/profile.php?user=764521

This font is a re-worked version of my Little Monster font. Despite the name it's actually the same size, but the lines of the capital letters are thicker and the lower case letters have mostly been redesigned.

It is 100% free to use, though credit is appreciated and it'd be cool to know where you used it. You must not claim it as your own.
