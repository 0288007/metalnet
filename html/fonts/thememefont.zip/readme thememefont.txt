THEmemefont.ttf is a free for personal use, is an amateur design =)
includes memes in upper and lower case, numbers and symbols

my site: http://truefonts.blogspot.com

direct link to the font http://truefonts.blogspot.com/2012/10/the-meme-font-thememefontttf.html

kaiserzharkhan