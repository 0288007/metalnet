Cr�ation : www.peax-webdesign.com
Utilisation commerciale et priv�e autoris�e

----------------------------------------------------------------------
Si vous appr�ciez cette police, vous pouvez :
- cr�diter d'un Google +1 sur ma page www.peax-webdesign.com
- liker ma page Facebook fr-fr.facebook.com/public/Peax-Webdesign
- ou ma page https://plus.google.com/103595703505477716588/posts
----------------------------------------------------------------------
if you like this font, please credit :

- Google +1 on www.peax-webdesign.com
- like  me on Facebook fr-fr.facebook.com/public/Peax-Webdesign
- or  https://plus.google.com/103595703505477716588/posts