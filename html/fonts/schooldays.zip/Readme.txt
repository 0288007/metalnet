IN ENGLISH FIRST - EN FRAN�AIS (UN PEU PLUS BAS)


A  FONT FOR FREE ! "Schooldays"
OFFERED TO YOU BY WWW.FRATERNET.COM

This font contains 26 attractive dingbats that you can get
on " a " to " z " letters. It's in TTF format
for Windows and weighs 33 ko.
Schooldays is freeware and you may freely distribute it to others
as long it will not be used for commercial purposes. 
You are welcome to use this font for personal web page but be nice
to give us a link at http://www.fraternet.com/font/
If you want to use this font for commercial purposes contact me first at
geoffroi@fraternet.com

In any case, please include this readme file with the font !

I seize the opportunity to enjoin you to see the webgraphics families
for your web site and the free buttons of my pal CYBER COUSETTE :
some wonders to download on http://www.fraternet.com/graphics/free/

NEW on FRATERNET.COM :

You are found of fonts, go'n'see our COOL FONTS from TYPONET
10 INVENTIVE AND ATTRACTIVE FONTS ! TAKE A LOOK:
Bab-El-Web, Junky Mail, Push Data Irregular, Ebone Fraktur,
Plug�n Gulp...
Brush-up your website !
http://www.fraternet.com/font/fonts.htm


*** Free to download ***
- Soccer World Cup Cliparts :
http://www.fraternet.com/france98/

Don't forget to subscribe to ZEL, our free newsletter of
Reciprocal Links : a super way to increase the traffic of your website !
visit http://www.fraternet.com/zel/
or subscribe :
mailto:zebulon@fraternet.com?subject=SUBSCRIBE

Also consult our magazine of spirituality (in French) :
http://www.fraternet.com/chemins.htm

See you soon for new free fonts. Love to  every one !

(Copyright � 1998, Les Chemins D'En Haut - All rights reserved)


EN FRAN�AIS


CETTE POLICE DE DINGBATS " Schooldays " VOUS EST OFFERTE PAR
WWW.FRATERNET.COM.

Cette police contient 26 dessins sympas que vous obtiendrez
en tapant les lettres " a " � " z ". Elle est au format TTF
pour Windows et p�se 33 ko.
" Schooldays " est distribu�e gratuitement (freeware ou graticiel)
et vous pouvez la donner autour de vous � condition qu'elle ne fasse
l'objet d'aucune utilisation commerciale.

Si vous l'utilisez sur votre page web personnelle, ce serait gentil de mettre
un lien � http://www.fraternet.com/font/
S'il s'agit d'une utilisation commerciale, contactez-moi :
geoffroi@fraternet.com

Dans tous les cas, ne s�parez pas le fichier TTF du pr�sent Readme !

NOUVEAU SUR FRATERNET.COM :
Vous �tes passionn�s de typographie
allez voir nos polices sympas sur TYPONET
10 polices originales et attrayantes ! Venez jeter un coup d'oeil sur :
Bab-El-Web, Junky Mail, Push Data Irregular, Ebone Fraktur,
Plug�n Gulp...
Pour �gayer votre site, vos courriers, vos rapports et bulletins !
http://www.fraternet.com/font/fonts.htm

J'en profite pour vous recommander d'aller voir aussi les familles d'�l�ments graphiques
pour votre site Web et les boutons gratuits de mon copain CYBER COUSETTE :
des merveilles � t�l�charger sur http://www.fraternet.com/graphics/free/

*** Gratuit � t�l�charger ***
- Cliparts de la Coupe du Monde de Football :
http://www.fraternet.com/france98/france.htm

N'oubliez pas de vous inscrire � ZEL, notre newsletter gratuite
d'�changes de liens, un moyen super d'accro�tre le trafic sur votre site :
http://www.fraternet.com/zel/zel.htm
ou abonnez-vous directement :
mailto:zebulon@fraternet.com?subject=INSCRIPTION

Lisez aussi notre revue de spiritualit� :
http://www.fraternet.com/chemins.htm

A bient�t pour de nouvelles polices gratuites. Amour � tous !

(Copyright � 1998, Les Chemins D'En Haut - Tous droits r�serv�s. )



