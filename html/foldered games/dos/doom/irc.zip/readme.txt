ngIRCd 26.1-1 for DOS

GitHub: https://github.com/mikechambers84/ngIRCd-DOS

This is the initial release of the DOS port.

System requirements:
- 8088 or better PC running DOS
- 640 KB RAM
- Ethernet adapter and a corresponding packet driver

You will need to create an mTCP config file.

See http://www.brutman.com/mTCP for more information.

Be sure to edit NGIRCD.CNF and adjust parameters for
your server/network. Optionally, edit MOTD.TXT

I recommend running this from a floppy disk, so that you
can remove it to edit the ngIRCd config and MOTD files
on another PC. Then you can reinsert the disk and rehash
from an oper login to reload the config without having
to shut down the server.

-Mike Chambers
7/30/2021
